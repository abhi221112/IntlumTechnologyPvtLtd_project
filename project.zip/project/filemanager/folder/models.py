# from django.db import models
# from django.contrib.auth.models import User

# class Folder(models.Model):
#     name = models.CharField(max_length=255)
#     parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='subfolders')
#     owner = models.ForeignKey(User, on_delete=models.CASCADE)
    
#     def __str__(self):
#         return self.name
    
#     def get_full_path(self):
#         if self.parent:
#             return f'{self.parent.get_full_path()}/{self.name}'
#         return self.name


#----------------------------------
# models.py
from django.db import models
from django.contrib.auth.models import User

class Folder(models.Model):
    name = models.CharField(max_length=255)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='subfolders')
    owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    def get_full_path(self):
        if self.parent:
            return f'{self.parent.get_full_path()}/{self.name}'
        return self.name
