# from django.urls import path
# from .views import dashboard, folder_create, folder_update, folder_delete,register,login_view,logout_view

# from . import views

# urlpatterns = [
#     path('', dashboard, name='dashboard'),
#     path('folder/create/', folder_create, name='folder_create'),
#     path('folder/create/<int:parent_id>/', folder_create, name='folder_create_subfolder'),
#     path('folder/update/<int:folder_id>/', folder_update, name='folder_update'),
#     path('folder/delete/<int:folder_id>/', folder_delete, name='folder_delete'),


#      #path('create_subfolder/<int:folder_id>/', views.create_subfolder, name='folder_create')
# ]





from django.urls import path
from .views import dashboard, folder_create, folder_update, folder_delete, register, login_view, logout_view

urlpatterns = [
    # Default login page instead of dashboard
    path('', login_view, name='login'),  # Make login page the default
    
    # Dashboard path (after login, redirect here)
    path('dashboard/', dashboard, name='dashboard'),
    
    # Folder-related paths
    path('folder/create/', folder_create, name='folder_create'),
    path('folder/create/<int:parent_id>/', folder_create, name='folder_create_subfolder'),
    path('folder/update/<int:folder_id>/', folder_update, name='folder_update'),
    path('folder/delete/<int:folder_id>/', folder_delete, name='folder_delete'),
    
    # Authentication paths
    path('register/', register, name='register'),
    path('logout/', logout_view, name='logout'),
]
