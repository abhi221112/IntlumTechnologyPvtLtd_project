from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Account created successfully!")
            return redirect('login')
        else:
            messages.error(request, "There was an error in the form.")
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid login credentials.")
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')


from django.shortcuts import render, get_object_or_404, redirect
from .models import Folder
from django.contrib.auth.decorators import login_required
from .forms import FolderForm

@login_required
def dashboard(request):
    # Display folders for the logged-in user
    folders = Folder.objects.filter(owner=request.user, parent=None)
    return render(request, 'dashboard.html', {'folders': folders})

@login_required
def folder_create(request, parent_id=None):
    print('hi')
    parent = None
    if parent_id:
        parent = get_object_or_404(Folder, id=parent_id, owner=request.user)
        print(f"Parent ID: {parent_id}")
    
    if request.method == 'POST':
        form = FolderForm(request.POST)
        if form.is_valid():
            folder = form.save(commit=False)
            folder.owner = request.user
            folder.parent = parent
            print(parent)
            folder.save()
            return redirect('dashboard')
    else:
        form = FolderForm()
    
    return render(request, 'folder_create.html', {'form': form, 'parent': parent})

@login_required
def folder_update(request, folder_id):
    folder = get_object_or_404(Folder, id=folder_id, owner=request.user)
    
    if request.method == 'POST':
        form = FolderForm(request.POST, instance=folder)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = FolderForm(instance=folder)
    
    return render(request, 'folder_update.html', {'form': form, 'folder': folder})

@login_required
def folder_delete(request, folder_id):
    folder = get_object_or_404(Folder, id=folder_id, owner=request.user)
    folder.delete()
    return redirect('dashboard')


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

